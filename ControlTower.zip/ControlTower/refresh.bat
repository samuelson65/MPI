@echo off
title Control Tower - refresh
cd /d "%~dp0"
call :findpy || goto nopy
%PY% build_dashboard.py --open
if errorlevel 1 (echo. & echo Something went wrong. If it mentions a missing package, run setup.bat. & pause & exit /b 1)
timeout /t 4 >nul
exit /b 0

:nopy
echo Python 3 was not found. Install it from https://www.python.org/downloads/
echo (tick "Add python.exe to PATH"), then double-click setup.bat.
pause
exit /b 1

:findpy
where py >nul 2>nul && (set "PY=py -3" & exit /b 0)
where python >nul 2>nul && (set "PY=python" & exit /b 0)
exit /b 1
