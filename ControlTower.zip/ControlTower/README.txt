ML MODEL CONTROL TOWER
======================

What is in this folder
----------------------
ML_Control_Tower.html     The dashboard. Open it in Chrome or Edge.
refresh.bat               Reads the Excel files and opens the updated dashboard.
watch.bat                 Keeps running and refreshes whenever you save an input file.
report.bat                Writes the biweekly PDF + Excel reports and email text.
setup.bat                 One-time install of the two Python packages.
build_dashboard.py        The script the .bat files run.
inputs\                   The Excel files the dashboard reads (put updated files here).
templates\                Blank copies of the input files, with dropdowns.
data\data.js              Written by the script. Do not edit.
output\refresh_report.xlsx  Rows that need fixing after each refresh.
output\reports\           Biweekly reports, one folder per fortnight.
output\history\           One small snapshot per day, used for "what changed".

The files in inputs\ right now contain SYNTHETIC SAMPLE DATA so you can see how
everything works. Replace them with your own (start from templates\).

First time
----------
1. Install Python 3 from https://www.python.org/downloads/ (tick "Add python.exe to PATH").
2. Double-click setup.bat.
3. Double-click refresh.bat. The dashboard opens.

The four input files
--------------------
Master.xlsx            You keep this one.
                       Models   - models in production: pod, segment, prepay/postpay,
                                  program, version, status, last retrained date.
                       Results  - optional monthly claims, findings and dollars.
                       Settings - optional: retrain cadence, report anchor date, etc.
                       Lists    - the dropdown values for every file: pods, segments,
                                  programs, people, types, statuses, priorities and
                                  target days. The script checks every file against these.
                                  After changing them, run
                                  "python build_dashboard.py --make-templates" for fresh
                                  blank files (with the new dropdowns) in templates\.
Program_Requests.xlsx  Share with program leads and members (DRG Coding, DRG CVA, APC,
                       Readmission). One row per issue or request.
Pod_Concerns.xlsx      Share with the pod specs (Humana, UHC, Aetna, Devoted).
                       One row per concern.
Developer_Log.xlsx     Share with the developers. One row per change or drift they see,
                       with numbers (Before / After, e.g. PSI) and a description.

Note: Pod_Concerns.xlsx is one file for all pods, so each pod can see the others' rows.
If that is not acceptable, give each pod its own copy (e.g. Pod_Concerns_Humana.xlsx).
The script reads every .xlsx in inputs\, so any number of files works.

Rules that keep it working
--------------------------
- Keep the header row as it is. Extra columns are ignored.
- Pick Pod, Segment and Program from the dropdowns. The dashboard links concerns,
  requests and developer notes to a model by these three names.
- The ID column is pre-filled (PC-0001, PR-0001, DL-0001). Do not change or reuse IDs.
- Do not delete closed rows. Set Status to Closed and fill Closed on.
- Leave Due / Target date blank to use the target days for the priority (Lists sheet).
- Never enter patient, member or claim identifiers. The script flags text that looks
  like one in output\refresh_report.xlsx.

Every update
------------
1. Save the updated Excel files into inputs\ (same file names, or new files).
2. Double-click refresh.bat. The dashboard opens with the new data.
   Or leave watch.bat running: save a file, and the open dashboard updates itself
   within about 30 seconds.
3. If anything could not be read, the Data sources page in the dashboard lists it,
   and so does output\refresh_report.xlsx (file, sheet, row, column, what to fix).

Biweekly reports
----------------
Double-click report.bat. It writes, for the last complete fortnight:
  Overall.pdf / .xlsx                    everything
  Pod - Humana.pdf / .xlsx (one per pod) only that pod's concerns, models and notes
  Program - APC.pdf / .xlsx (one per program)
  email_summaries.txt                    ready-to-paste email text for each
Fortnights start on report_anchor_date in Settings (a Monday; default 2026-01-05).
For a different period:  python build_dashboard.py --report --period-end 2026-11-15

Optional: run it on a schedule
------------------------------
Windows Task Scheduler > Create Basic Task > Daily > Start a program >
Program: the full path to refresh.bat (or report.bat every other Monday).

Troubleshooting
---------------
"Python was not found"     Install Python (step 1) and run setup.bat.
"openpyxl is missing"      Run setup.bat.
A file is open in Excel    The script reads a copy, so you can keep it open.
Dashboard shows sample     Make sure data\data.js sits next to the HTML file and
                           refresh.bat finished without errors.
