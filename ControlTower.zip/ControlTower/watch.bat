@echo off
title Control Tower - watching inputs (close this window to stop)
cd /d "%~dp0"
call :findpy || goto nopy
%PY% build_dashboard.py --watch --open
pause
exit /b 0

:nopy
echo Python 3 was not found. Install it from https://www.python.org/downloads/
echo (tick "Add python.exe to PATH"), then double-click setup.bat.
pause
exit /b 1

:findpy
where py >nul 2>nul && (set "PY=py -3" & exit /b 0)
where python >nul 2>nul && (set "PY=python" & exit /b 0)
exit /b 1
