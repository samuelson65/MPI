#!/usr/bin/env python3
"""
ML Model Control Tower - refresh and report script
==================================================

Reads the Excel files in the inputs folder, checks every row, and writes
data/data.js, which ML_Control_Tower.html loads. Optionally writes the
biweekly PDF and Excel reports for each pod, each program and overall.

Usage (or just double-click the .bat files):
    python build_dashboard.py                  refresh the dashboard data
    python build_dashboard.py --open           refresh, then open the dashboard
    python build_dashboard.py --watch          refresh whenever an input file is saved
    python build_dashboard.py --report         refresh + reports for the last complete fortnight
    python build_dashboard.py --report --period-end 2026-11-15
    python build_dashboard.py --make-templates write blank input files to templates/

Needs Python 3.8+ with:  python -m pip install openpyxl fpdf2
"""
import argparse
import datetime as dt
import difflib
import glob
import json
import os
import re
import shutil
import statistics
import sys
import tempfile
import time
import unicodedata
from collections import OrderedDict, defaultdict

try:
    import openpyxl
    from openpyxl.comments import Comment
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.datavalidation import DataValidation
except ImportError:
    print("The openpyxl package is missing. Double-click setup.bat, or run:  python -m pip install openpyxl fpdf2")
    sys.exit(2)

ROOT = os.path.dirname(os.path.abspath(__file__))
INPUTS = os.path.join(ROOT, "inputs")
DATA_DIR = os.path.join(ROOT, "data")
OUT_DIR = os.path.join(ROOT, "output")
HTML = os.path.join(ROOT, "ML_Control_Tower.html")
FONTS = os.path.join(ROOT, "assets", "fonts")

# ---------------------------------------------------------------------------
# Sheet definitions: one place that drives reading, checking and templates.
# kind: text, date, month, int, num, rate, list:<List name>, enum:<a|b|c>
# ---------------------------------------------------------------------------
def col(key, label, kind="text", req=False, width=14, help="", aliases=()):
    return dict(key=key, label=label, kind=kind, req=req, width=width, help=help, aliases=aliases)

MODEL_STATUS = "Production|Validation|Approved|Development|Retired|Rolled back"
SHEETS = OrderedDict([
    ("Models", dict(file="Master", owner="You", note="One row per model in production (or in build). Add older versions as Retired rows if you want version history.",
        cols=[col("pod", "Pod", "list:Pod", True, 12, "Client: Humana, UHC, Aetna, Devoted…", ("client",)),
              col("segment", "Segment", "list:Segment", True, 14, "Postpay, Prepay, COSMOS, UNET, HRP, ACAS…"),
              col("payment_type", "Payment type", "enum:Postpay|Prepay", False, 13, "Leave blank when the segment already says Prepay or Postpay"),
              col("program", "Program", "list:Program", True, 14),
              col("version", "Version", "text", True, 9, "Version in production, e.g. 2.1"),
              col("status", "Status", "enum:" + MODEL_STATUS, True, 12),
              col("last_retrained", "Last retrained", "date", True, 14, "Date the current version was trained", ("trained on", "train date", "last trained")),
              col("deployed_on", "Deployed on", "date", False, 13),
              col("owner", "Owner", "list:Person", False, 16),
              col("cadence_days", "Retrain every (days)", "int", False, 12, "Leave blank to use the default in Settings"),
              col("training_records", "Training records", "int", False, 14),
              col("precision", "Precision", "rate", False, 10, "Test-set precision, 0.68 or 68%"),
              col("recall", "Recall", "rate", False, 10),
              col("rollback_date", "Rolled back on", "date", False, 13),
              col("notes", "Notes", "text", False, 30)])),
    ("Results", dict(file="Master", owner="You", optional=True, note="Optional. Monthly business results per model. Leave empty if you do not track dollars.",
        cols=[col("month", "Month", "month", True, 10, "YYYY-MM or Oct 2026"),
              col("pod", "Pod", "list:Pod", True, 12, aliases=("client",)), col("segment", "Segment", "list:Segment", True, 14), col("program", "Program", "list:Program", True, 14),
              col("claims_scored", "Claims scored", "int", True, 13), col("claims_selected", "Claims selected", "int", False, 13),
              col("findings", "Findings", "int", False, 10), col("confirmed_findings", "Confirmed findings", "int", False, 13),
              col("validated_amount", "Validated $", "num", False, 13), col("recovered_amount", "Recovered $", "num", False, 13, "Only where recovery is attributable to the model"),
              col("precision", "Precision", "rate", False, 10), col("recall", "Recall", "rate", False, 10)])),
    ("Settings", dict(file="Master", owner="You", optional=True, note="Optional. Add a row only to change a default.",
        cols=[col("setting", "Setting", "text", True, 30), col("value", "Value", "text", True, 20)])),
    ("Requests", dict(file="Program_Requests", owner="Program leads and members", id_prefix="PR",
        note="One row per issue or request from a program team. Do not enter patient, member or claim identifiers.",
        cols=[col("id", "ID", "text", True, 9, "Pre-filled. Do not change."),
              col("date", "Date raised", "date", True, 12, aliases=("raised on", "date")),
              col("raised_by", "Raised by", "list:Person", True, 16), col("role", "Role", "enum:Program lead|Member", False, 13),
              col("program", "Program", "list:Program", True, 14), col("pod", "Pod", "list:Pod", False, 11, "Optional: the client it relates to"),
              col("segment", "Segment", "list:Segment", False, 12, "Optional"),
              col("type", "Type", "list:Request type", True, 14), col("priority", "Priority", "list:Priority", True, 10),
              col("title", "Title", "text", True, 36, "One line"), col("description", "Description", "text", False, 50),
              col("status", "Status", "list:Status", True, 12), col("owner", "Assigned to", "list:Person", False, 16, aliases=("owner", "assigned")),
              col("due", "Target date", "date", False, 12, "Blank = date raised + target days for the priority", ("due date",)),
              col("closed_on", "Closed on", "date", False, 12), col("resolution", "Resolution", "text", False, 50)])),
    ("Concerns", dict(file="Pod_Concerns", owner="Pod specs", id_prefix="PC",
        note="One row per concern from a pod (client team). Do not enter patient, member or claim identifiers.",
        cols=[col("id", "ID", "text", True, 9, "Pre-filled. Do not change."),
              col("date", "Date raised", "date", True, 12, aliases=("raised on",)),
              col("pod", "Pod", "list:Pod", True, 11), col("segment", "Segment", "list:Segment", False, 12, "Optional"),
              col("program", "Program", "list:Program", False, 14, "Optional"),
              col("raised_by", "Raised by", "list:Person", True, 16), col("type", "Concern type", "list:Concern type", True, 16),
              col("priority", "Priority", "list:Priority", True, 10),
              col("title", "Title", "text", True, 36, "One line"), col("description", "Description", "text", False, 50),
              col("status", "Status", "list:Status", True, 12), col("owner", "Owner", "list:Person", False, 16),
              col("due", "Due date", "date", False, 12, "Blank = date raised + target days for the priority", ("target date",)),
              col("closed_on", "Closed on", "date", False, 12), col("resolution", "Response", "text", False, 50, aliases=("resolution",))])),
    ("Developer log", dict(file="Developer_Log", owner="Developers", id_prefix="DL",
        note="One row per change or drift seen in training or scoring data. Before/After take numbers; Details takes the description.",
        cols=[col("id", "ID", "text", True, 9, "Pre-filled. Do not change."),
              col("date", "Date", "date", True, 12), col("developer", "Developer", "list:Person", True, 16),
              col("pod", "Pod", "list:Pod", True, 11), col("segment", "Segment", "list:Segment", True, 12), col("program", "Program", "list:Program", True, 14),
              col("version", "Version", "text", False, 9),
              col("change_type", "Change type", "list:Change type", True, 16), col("area", "Feature / area", "text", False, 22),
              col("metric", "Metric", "list:Metric", False, 18, "What the numbers measure"),
              col("before", "Before", "num", False, 10), col("after", "After", "num", False, 10),
              col("severity", "Severity", "enum:High|Medium|Low", False, 10), col("details", "Details", "text", True, 50),
              col("action", "Action taken", "text", False, 40), col("status", "Status", "enum:Open|Closed", False, 10)])),
])
LIST_COLS = ["Pod", "Segment", "Program", "Person", "Request type", "Concern type", "Change type", "Metric", "Status", "Priority", "Target days"]
DEFAULT_LISTS = {
    "Pod": ["Humana", "UHC", "Aetna", "Devoted"],
    "Segment": ["Postpay", "Prepay", "COSMOS", "UNET", "HRP", "ACAS", "Medicare Advantage"],
    "Program": ["DRG Coding", "DRG CVA", "APC", "Readmission"],
    "Person": [],
    "Request type": ["Issue", "Enhancement", "New model", "Data request", "Rule change", "Question"],
    "Concern type": ["Finding quality", "Volume / selection rate", "Turnaround", "Appeal overturns", "Data feed", "Provider abrasion", "Reporting", "Other"],
    "Change type": ["Drift observed", "Data refresh", "Feature added", "Feature removed", "Code-set update", "Retrained", "Data quality issue", "Bug fix", "Threshold change"],
    "Metric": ["Feature PSI", "Prediction PSI", "Missing feature rate", "Scoring failure rate", "Latency p95 (ms)", "Data quality score", "Records added", "Precision", "Recall", "Hit rate", "Other"],
    "Status": ["Open", "In progress", "On hold", "Closed"],
    "Priority": ["High", "Medium", "Low"],
    "Target days": [5, 15, 30],
}
DEFAULT_SETTINGS = {"retrain_cadence_days": "180", "report_anchor_date": "2026-01-05", "stale_file_days": "14"}
# Developer-log metric -> dashboard health signal, and whether values are rates
METRIC_SIGNAL = [("prediction psi", "prediction_psi", False), ("psi", "feature_psi", False), ("drift", "feature_psi", False),
                 ("missing", "missing_rate", True), ("fail", "failure_rate", True), ("latency", "latency_ms", False),
                 ("quality", "data_quality", False), ("precision", "precision", True), ("recall", "recall", True), ("hit rate", "hit_rate", True)]
PHI_PATTERNS = [re.compile(r"\b\d{9,}\b"), re.compile(r"\b[A-Z]{1,3}\d{7,}\b"), re.compile(r"\b(mrn|member\s*id|claim\s*(id|no|number)|ssn|dob)\b", re.I)]


# ---------------------------------------------------------------------------
# value parsers
# ---------------------------------------------------------------------------
def norm(s):
    return re.sub(r"[^a-z0-9]", "", str(s if s is not None else "").lower())


def blank(v):
    return v is None or (isinstance(v, str) and v.strip() == "")


DATE_FORMATS = ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%d %b %Y", "%d %B %Y", "%d-%b-%Y", "%d-%b-%y",
                "%b %d %Y", "%B %d %Y", "%b %d, %Y", "%B %d, %Y", "%Y/%m/%d", "%Y-%m-%d %H:%M:%S", "%d/%m/%y")


def p_date(v):
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    if isinstance(v, (int, float)) and 20000 < v < 80000:
        return dt.date(1899, 12, 30) + dt.timedelta(days=int(v))
    s = str(v).strip()
    if re.fullmatch(r"\d{5}(\.0+)?", s) and 20000 < float(s) < 80000:
        return dt.date(1899, 12, 30) + dt.timedelta(days=int(float(s)))
    for f in DATE_FORMATS:
        try:
            return dt.datetime.strptime(s, f).date()
        except ValueError:
            pass
    raise ValueError("Use a date like 2026-11-18 or 18/11/2026")


def p_month(v):
    if isinstance(v, (dt.date, dt.datetime)):
        return f"{v.year}-{v.month:02d}"
    s = str(v).strip()
    m = re.match(r"^(\d{4})[-/.](\d{1,2})(?:[-/.]\d{1,2})?$", s)
    if m and 1 <= int(m.group(2)) <= 12:
        return f"{m.group(1)}-{int(m.group(2)):02d}"
    m = re.match(r"^(\d{1,2})[-/.](\d{4})$", s)
    if m and 1 <= int(m.group(1)) <= 12:
        return f"{m.group(2)}-{int(m.group(1)):02d}"
    for f in ("%b %Y", "%B %Y", "%b-%Y", "%b-%y", "%b %y", "%B-%Y"):
        try:
            d = dt.datetime.strptime(s, f)
            return f"{d.year}-{d.month:02d}"
        except ValueError:
            pass
    try:
        d = p_date(v)
        return f"{d.year}-{d.month:02d}"
    except ValueError:
        raise ValueError("Use a month like 2026-10 or Oct 2026")


def p_num(v):
    if isinstance(v, bool):
        raise ValueError("Enter a number")
    if isinstance(v, (int, float)):
        return float(v)
    s = re.sub(r"[,\s$₹€£]", "", str(v))
    pct = s.endswith("%")
    try:
        x = float(s.rstrip("%"))
    except ValueError:
        raise ValueError("Enter a number")
    return x / 100 if pct else x


def p_int(v):
    x = p_num(v)
    if x < 0:
        raise ValueError("Cannot be negative")
    return int(round(x))


def p_rate(v):
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        x = float(v)
    else:
        s = str(v).strip()
        pct = s.endswith("%")
        try:
            x = float(s.rstrip("%").replace(",", "").strip())
        except ValueError:
            raise ValueError("Enter 0-1 or a percentage")
        if pct:
            x /= 100
    if x > 1:
        x /= 100
    if not 0 <= x <= 1:
        raise ValueError("Must be between 0 and 1 (or 0-100%)")
    return x


def iso(d):
    return d.isoformat() if isinstance(d, (dt.date, dt.datetime)) else (d or "")


def fmt_date(d):
    if not d:
        return ""
    if isinstance(d, str):
        d = dt.date.fromisoformat(d[:10])
    return d.strftime("%d %b %Y")


# ---------------------------------------------------------------------------
# reading workbooks
# ---------------------------------------------------------------------------
class Log:
    def __init__(self):
        self.problems = []

    def add(self, level, file, sheet, row, column, message):
        self.problems.append(dict(level=level, file=file, sheet=sheet, row=row, column=column, message=message))


def open_workbook(path):
    try:
        return openpyxl.load_workbook(path, read_only=True, data_only=True)
    except PermissionError:
        tmp = os.path.join(tempfile.gettempdir(), "ct_copy_" + os.path.basename(path))
        shutil.copyfile(path, tmp)
        return openpyxl.load_workbook(tmp, read_only=True, data_only=True)


def sheet_key(name):
    n = norm(name)
    for k in list(SHEETS) + ["Lists"]:
        if norm(k) == n:
            return k
    aliases = {"devlog": "Developer log", "log": "Developer log", "developerlog": "Developer log", "concern": "Concerns", "podconcerns": "Concerns",
               "request": "Requests", "programrequests": "Requests", "modelsinproduction": "Models", "model": "Models", "monthly": "Results", "impact": "Results", "list": "Lists"}
    return aliases.get(n)


def header_map(spec, cells):
    out = {}
    for j, h in enumerate(cells):
        n = norm(h)
        if not n:
            continue
        for c in spec["cols"]:
            if n in (norm(c["label"]), norm(c["key"])) or n in [norm(a) for a in c["aliases"]]:
                out[j] = c["key"]
                break
    return out


def read_sheet_rows(ws, spec):
    rows = list(ws.iter_rows(values_only=True))
    for hi in range(min(6, len(rows))):
        hm = header_map(spec, rows[hi] or [])
        if len(hm) >= 2:
            break
    else:
        return None, []
    data = []
    for i in range(hi + 1, len(rows)):
        cells = rows[i] or []
        rec = {k: cells[j] if j < len(cells) else None for j, k in hm.items()}
        filled = [k for k, v in rec.items() if not blank(v)]
        if not filled or filled == ["id"]:
            continue
        data.append((i + 1, rec))
    return hm, data


def read_lists(ws):
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return {}
    hdr = [str(h).strip() if h else "" for h in rows[0]]
    out = {}
    for j, h in enumerate(hdr):
        name = next((c for c in LIST_COLS if norm(c) == norm(h)), None)
        if not name:
            continue
        out[name] = [r[j] for r in rows[1:] if j < len(r) and not blank(r[j])]
    return out


def discover_inputs(folder):
    files = [f for f in glob.glob(os.path.join(folder, "*.xlsx")) + glob.glob(os.path.join(folder, "*.xlsm"))
             if not os.path.basename(f).startswith("~$")]
    return sorted(files)


def read_inputs(folder, log):
    raw = defaultdict(list)          # sheet -> [(file, rownum, record)]
    lists, files, master_lists = {}, [], None
    for path in discover_inputs(folder):
        name = os.path.basename(path)
        info = dict(name=name, modified=dt.datetime.fromtimestamp(os.path.getmtime(path)).isoformat(timespec="minutes"), sheets=[], rows=0)
        try:
            wb = open_workbook(path)
        except Exception as e:  # noqa: BLE001
            log.add("error", name, "", "", "", f"Could not open the file ({e.__class__.__name__}). Close it in Excel or check it is a valid .xlsx.")
            files.append(info)
            continue
        for ws in wb.worksheets:
            key = sheet_key(ws.title)
            if not key:
                continue
            if key == "Lists":
                got = read_lists(ws)
                if any(norm(w.title) == "models" for w in wb.worksheets):
                    master_lists = got          # the Master file's Lists win
                for k, v in got.items():
                    if v:
                        lists.setdefault(k, [])
                        lists[k] += [x for x in v if x not in lists[k]]
                info["sheets"].append("Lists")
                continue
            hm, data = read_sheet_rows(ws, SHEETS[key])
            if hm is None:
                log.add("warning", name, ws.title, 1, "", "No recognisable header row; sheet skipped. Keep the template headers.")
                continue
            missing = [c["label"] for c in SHEETS[key]["cols"] if c["req"] and c["key"] not in hm.values()]
            if missing:
                log.add("error", name, ws.title, 1, ", ".join(missing), "Required column(s) missing from the header row.")
            for rn, rec in data:
                raw[key].append((name, ws.title, rn, rec))
            info["sheets"].append(ws.title)
            info["rows"] += len(data)
        wb.close()
        files.append(info)
    if master_lists:
        lists = {k: v for k, v in master_lists.items() if v}
    for k, v in DEFAULT_LISTS.items():
        if not lists.get(k):
            lists[k] = list(v)
    return raw, lists, files


# ---------------------------------------------------------------------------
# checking and normalising rows
# ---------------------------------------------------------------------------
def canon_list(value, options, what, ctx, log):
    s = str(value).strip()
    if not options:
        return s
    by = {norm(o): str(o) for o in options}
    if norm(s) in by:
        return by[norm(s)]
    close = difflib.get_close_matches(norm(s), list(by), n=1, cutoff=0.8)
    if close:
        log.add("warning", *ctx, f"'{s}' is not in the {what} list; read as '{by[close[0]]}'. Fix the cell or add it to Lists.")
        return by[close[0]]
    log.add("warning", *ctx, f"'{s}' is not in the {what} list. Add it to the Lists sheet if it is new.")
    return s


def clean_rows(key, entries, lists, log):
    spec = SHEETS[key]
    out, seen_ids = [], {}
    for file, sheet, rn, rec in entries:
        row, bad = {"_file": file, "_row": rn}, False
        for c in spec["cols"]:
            v = rec.get(c["key"])
            ctx = (file, sheet, rn, c["label"])
            if blank(v):
                if c["req"]:
                    log.add("error", *ctx, "Required; row left out until filled.")
                    bad = True
                row[c["key"]] = None
                continue
            kind = c["kind"]
            try:
                if kind == "date":
                    row[c["key"]] = p_date(v)
                elif kind == "month":
                    row[c["key"]] = p_month(v)
                elif kind == "int":
                    row[c["key"]] = p_int(v)
                elif kind == "num":
                    row[c["key"]] = p_num(v)
                elif kind == "rate":
                    row[c["key"]] = p_rate(v)
                elif kind.startswith("enum:"):
                    opts = kind[5:].split("|")
                    row[c["key"]] = canon_list(v, opts, c["label"], ctx, log)
                    if row[c["key"]] not in opts:
                        log.add("error", *ctx, f"Use one of: {', '.join(opts)}")
                        bad = c["req"] or bad
                        row[c["key"]] = None
                elif kind.startswith("list:"):
                    row[c["key"]] = canon_list(v, lists.get(kind[5:], []), kind[5:], ctx, log)
                elif c["key"] == "version" and isinstance(v, (int, float)) and not isinstance(v, bool):
                    row[c["key"]] = f"{int(v)}.0" if float(v).is_integer() else f"{v:g}"
                elif isinstance(v, (dt.datetime, dt.date)):
                    row[c["key"]] = (v.date() if isinstance(v, dt.datetime) else v).isoformat()
                else:
                    row[c["key"]] = str(v).strip()
            except ValueError as e:
                log.add("error", *ctx, str(e) + ("; row left out until fixed." if c["req"] else "; value ignored."))
                row[c["key"]] = None
                bad = bad or c["req"]
        if bad:
            continue
        if "id" in row:
            ident = str(row["id"]).strip()
            k = (file, ident)
            if k in seen_ids:
                log.add("error", file, sheet, rn, "ID", f"Duplicate ID {ident} (also row {seen_ids[k]}); this row was left out.")
                continue
            seen_ids[k] = rn
        for f in ("title", "description", "resolution", "details", "action", "area", "notes"):
            if row.get(f) and any(p.search(str(row[f])) for p in PHI_PATTERNS):
                log.add("warning", file, sheet, rn, f.replace("_", " ").title(),
                        "Looks like it may contain a patient, member or claim identifier. Remove it before sharing.")
        out.append(row)
    return out


def settings_from(rows):
    s = dict(DEFAULT_SETTINGS)
    for r in rows:
        if r.get("setting"):
            s[str(r["setting"]).strip()] = str(r.get("value") if r.get("value") is not None else "").strip()
    return s


def cadence_for(model, settings):
    if model.get("cadence_days"):
        return int(model["cadence_days"])
    for k in (f"retrain_cadence_days:{model['program']}", "retrain_cadence_days"):
        try:
            return int(float(settings[k]))
        except (KeyError, ValueError):
            pass
    return 180


def targets_from(lists):
    pr, td = lists.get("Priority", []), lists.get("Target days", [])
    out = {}
    for i, p in enumerate(pr):
        try:
            out[str(p)] = int(float(td[i]))
        except (IndexError, ValueError, TypeError):
            out[str(p)] = {"high": 5, "medium": 15, "low": 30}.get(norm(p), 15)
    return out or {"High": 5, "Medium": 15, "Low": 30}


def build_items(req_rows, con_rows, targets, today, log):
    items = []
    for kind, rows in (("Request", req_rows), ("Concern", con_rows)):
        for r in rows:
            due, src = r.get("due"), "entered"
            if not due:
                due, src = r["date"] + dt.timedelta(days=targets.get(r["priority"], 15)), "target"
            closed = norm(r["status"]) == "closed"
            if closed and not r.get("closed_on"):
                log.add("warning", r["_file"], kind + "s", r["_row"], "Closed on", "Status is Closed; add the date it was closed so turnaround can be measured.")
            if r.get("closed_on") and r["closed_on"] < r["date"]:
                log.add("warning", r["_file"], kind + "s", r["_row"], "Closed on", "Closed before it was raised; check the dates.")
            if r.get("closed_on") and not closed:
                log.add("warning", r["_file"], kind + "s", r["_row"], "Status", "A closed date is set but status is not Closed.")
            end = r.get("closed_on") if closed and r.get("closed_on") else today
            items.append(dict(
                key=f"{kind[0]}:{r['_file']}:{r['id']}", id=str(r["id"]), kind=kind, file=r["_file"], row=r["_row"],
                date=iso(r["date"]), raised_by=r.get("raised_by") or "", role=r.get("role") or "", pod=r.get("pod") or "",
                segment=r.get("segment") or "", program=r.get("program") or "", type=r.get("type") or "",
                priority=r.get("priority") or "", title=r.get("title") or "", description=r.get("description") or "",
                status=r.get("status") or "", owner=r.get("owner") or "", due=iso(due), due_source=src,
                closed_on=iso(r.get("closed_on")), resolution=r.get("resolution") or "",
                open=not closed, age_days=max(0, (end - r["date"]).days),
                overdue=(not closed) and norm(r["status"]) != "onhold" and due < today))
    return items


def build_devlog(rows):
    out = []
    for r in rows:
        sig, is_rate = None, False
        m = norm(r.get("metric"))
        for needle, s, rate in METRIC_SIGNAL:
            if norm(needle) in m:
                sig, is_rate = s, rate
                break
        def val(x):
            if x is None:
                return None
            return x / 100 if is_rate and x > 1 else x
        out.append(dict(key=f"D:{r['_file']}:{r['id']}", id=str(r["id"]), file=r["_file"], row=r["_row"], date=iso(r["date"]),
                        developer=r.get("developer") or "", pod=r.get("pod") or "", segment=r.get("segment") or "", program=r.get("program") or "",
                        version=r.get("version") or "", change_type=r.get("change_type") or "", area=r.get("area") or "",
                        metric=r.get("metric") or "", before=val(r.get("before")), after=val(r.get("after")), signal=sig, is_rate=is_rate,
                        severity=r.get("severity") or "", details=r.get("details") or "", action=r.get("action") or "", status=r.get("status") or ""))
    return out


# ---------------------------------------------------------------------------
# refresh
# ---------------------------------------------------------------------------
def build(today=None, quiet=False):
    t0 = time.time()
    today = today or dt.date.today()
    log = Log()
    os.makedirs(INPUTS, exist_ok=True)
    raw, lists, files = read_inputs(INPUTS, log)
    if not files:
        log.add("error", "", "", "", "", f"No Excel files found in {INPUTS}. Copy the files from templates/ there.")
    models = clean_rows("Models", raw["Models"], lists, log)
    results = clean_rows("Results", raw["Results"], lists, log)
    settings_rows = clean_rows("Settings", raw["Settings"], lists, log)
    settings = settings_from(settings_rows)
    requests_ = clean_rows("Requests", raw["Requests"], lists, log)
    concerns = clean_rows("Concerns", raw["Concerns"], lists, log)
    devrows = clean_rows("Developer log", raw["Developer log"], lists, log)
    if not models:
        log.add("warning", "", "Models", "", "", "No model rows were read. The dashboard will be empty until the Models sheet has rows.")
    seen = {}
    for m in models:
        k = (norm(m["pod"]), norm(m["segment"]), norm(m["program"]), str(m["version"]))
        if k in seen:
            log.add("error", m["_file"], "Models", m["_row"], "Version", f"Same pod, segment, program and version as row {seen[k]}.")
        seen[k] = m["_row"]
    model_keys = {(norm(m["pod"]), norm(m["segment"]), norm(m["program"])) for m in models}
    for r in devrows:
        if (norm(r["pod"]), norm(r["segment"]), norm(r["program"])) not in model_keys:
            log.add("warning", r["_file"], "Developer log", r["_row"], "Program", "No model on the Models sheet matches this pod, segment and program.")
    targets = targets_from(lists)
    items = build_items(requests_, concerns, targets, today, log)
    devlog = build_devlog(devrows)
    stale_days = int(float(settings.get("stale_file_days", 14) or 14))
    for f in files:
        f["age_days"] = (dt.datetime.now() - dt.datetime.fromisoformat(f["modified"])).days
        f["stale"] = f["age_days"] > stale_days
        f["problems"] = sum(1 for p in log.problems if p["file"] == f["name"] and p["level"] == "error")
        f["warnings"] = sum(1 for p in log.problems if p["file"] == f["name"] and p["level"] == "warning")
    simple = dict(
        Models=[dict(client=m["pod"], segment=m["segment"], program=m["program"], version=str(m["version"]), status=m["status"],
                     train_date=iso(m["last_retrained"]), training_records=m.get("training_records"), precision=m.get("precision"),
                     recall=m.get("recall"), deploy_date=iso(m.get("deployed_on")), rollback_date=iso(m.get("rollback_date")),
                     payment_type=m.get("payment_type") or "", owner=m.get("owner") or "", notes=m.get("notes") or "",
                     cadence_days=m.get("cadence_days")) for m in models],
        Monthly=[dict(month=r["month"], client=r["pod"], segment=r["segment"], program=r["program"], claims_scored=r["claims_scored"],
                      claims_selected=r.get("claims_selected"), findings=r.get("findings"), confirmed_findings=r.get("confirmed_findings"),
                      validated_amount=r.get("validated_amount"), recovered_amount=r.get("recovered_amount"),
                      precision=r.get("precision"), recall=r.get("recall")) for r in results],
        Settings=[dict(setting=k, value=v) for k, v in settings.items() if k not in DEFAULT_SETTINGS or k == "retrain_cadence_days"])
    for t in simple.values():
        for r in t:
            for k in list(r):
                if r[k] is None:
                    r[k] = ""
    payload = dict(version=2, generated=dt.datetime.now().isoformat(timespec="seconds"), today=iso(today), inputs=INPUTS,
                   files=files, simple=simple, items=items, devlog=devlog, lists={k: [str(x) for x in v] for k, v in lists.items()},
                   targets=targets, settings=settings, problems=log.problems, reports=list_reports())
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = os.path.join(DATA_DIR, "data.js.tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write("/* Written by build_dashboard.py. Do not edit; edit the Excel files in inputs/ instead. */\n")
        fh.write("window.CT_DATA = " + json.dumps(payload, default=str, ensure_ascii=False).replace("</", "<\\/") + ";\n")
    os.replace(tmp, os.path.join(DATA_DIR, "data.js"))
    write_refresh_report(log, files)
    snapshot(items, today)
    ctx = dict(models=models, results=results, settings=settings, items=items, devlog=devlog, lists=lists, today=today, log=log, files=files)
    if not quiet:
        e = sum(p["level"] == "error" for p in log.problems)
        w = sum(p["level"] == "warning" for p in log.problems)
        print(f"Read {len(files)} file(s): {len(models)} model rows, {len(results)} result rows, {len(requests_)} requests, "
              f"{len(concerns)} concerns, {len(devlog)} developer log entries.")
        print(f"{e} error(s), {w} warning(s)" + (" - see output/refresh_report.xlsx" if e or w else "") +
              f". Dashboard data written in {time.time() - t0:.1f}s.")
        for f in files:
            if f.get("stale"):
                print(f"  Note: {f['name']} was last saved {f['age_days']} days ago.")
    return ctx


def write_refresh_report(log, files):
    os.makedirs(OUT_DIR, exist_ok=True)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Problems"
    hdr = ["Level", "File", "Sheet", "Row", "Column", "What to fix"]
    ws.append(hdr)
    order = {"error": 0, "warning": 1, "note": 2}
    for p in sorted(log.problems, key=lambda p: (order.get(p["level"], 3), p["file"], p["sheet"], p["row"] if isinstance(p["row"], int) else 0)):
        ws.append([p["level"].title(), p["file"], p["sheet"], p["row"], p["column"], p["message"]])
    if not log.problems:
        ws.append(["", "", "", "", "", "No problems found. Every row was read."])
    style_table(ws, [9, 24, 16, 6, 18, 90])
    for r in ws.iter_rows(min_row=2):
        if r[0].value == "Error":
            r[0].font = Font(bold=True, color="B42318")
    ws2 = wb.create_sheet("Files")
    ws2.append(["File", "Sheets read", "Rows", "Last saved", "Days since saved", "Errors", "Warnings"])
    for f in files:
        ws2.append([f["name"], ", ".join(f["sheets"]), f["rows"], f["modified"].replace("T", " "), f.get("age_days"), f.get("problems"), f.get("warnings")])
    style_table(ws2, [28, 40, 8, 18, 14, 8, 10])
    safe_save(wb, os.path.join(OUT_DIR, "refresh_report.xlsx"))


def safe_save(wb, path):
    try:
        wb.save(path)
    except PermissionError:
        alt = path.replace(".xlsx", f"_{dt.datetime.now():%H%M%S}.xlsx")
        wb.save(alt)
        print(f"  {os.path.basename(path)} is open in Excel; saved as {os.path.basename(alt)} instead.")


def snapshot(items, today):
    d = os.path.join(OUT_DIR, "history")
    os.makedirs(d, exist_ok=True)
    snap = {i["key"]: dict(status=i["status"], priority=i["priority"], owner=i["owner"], due=i["due"]) for i in items}
    with open(os.path.join(d, f"{today.isoformat()}.json"), "w", encoding="utf-8") as fh:
        json.dump(dict(date=today.isoformat(), items=snap), fh)


def load_snapshot_on_or_before(day):
    d = os.path.join(OUT_DIR, "history")
    best = None
    for p in glob.glob(os.path.join(d, "*.json")):
        try:
            sd = dt.date.fromisoformat(os.path.basename(p)[:10])
        except ValueError:
            continue
        if sd <= day and (best is None or sd > best[0]):
            best = (sd, p)
    if not best:
        return None
    with open(best[1], encoding="utf-8") as fh:
        return json.load(fh)


def list_reports():
    base = os.path.join(OUT_DIR, "reports")
    out = []
    for d in sorted(glob.glob(os.path.join(base, "*")), reverse=True):
        if os.path.isdir(d):
            fs = sorted(os.path.basename(f) for f in glob.glob(os.path.join(d, "*")) if os.path.isfile(f))
            out.append(dict(period=os.path.basename(d), files=[dict(name=f, path=f"output/reports/{os.path.basename(d)}/{f}") for f in fs]))
    return out[:12]


# ---------------------------------------------------------------------------
# Excel helpers and templates
# ---------------------------------------------------------------------------
HDR_FILL = PatternFill("solid", fgColor="1C2628")
REQ_FILL = PatternFill("solid", fgColor="E8A33D")


def style_table(ws, widths):
    for j, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(j)].width = w
        c = ws.cell(row=1, column=j)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = HDR_FILL
    ws.freeze_panes = "A2"
    if ws.max_row > 1:
        ws.auto_filter.ref = ws.dimensions
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.alignment = Alignment(vertical="top", wrap_text=isinstance(c.value, str) and len(c.value) > 40)


def write_input_workbook(path, sheet_keys, rows_by_sheet, lists, settings_rows=None, id_rows=500, readme_title=None):
    """Write an input workbook with dropdowns, header help and (for logs) pre-filled IDs."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "README"
    lines = [readme_title or "ML Model Control Tower input file", "",
             "Fill in the sheet(s) in this file. Orange headers are required; hover a header for help.",
             "Pick values from the dropdowns so names match across files (the dashboard links rows by Pod, Segment and Program).",
             "Keep closed items: set Status to Closed and fill Closed on. Do not delete rows.",
             "Do not enter patient, member or claim identifiers anywhere in this file.", ""]
    for k in sheet_keys:
        lines.append(f"{k}: {SHEETS[k]['note']}")
    for i, t in enumerate(lines, 1):
        c = ws.cell(row=i, column=1, value=t)
        if i == 1:
            c.font = Font(bold=True, size=14)
    ws.column_dimensions["A"].width = 120
    lst = wb.create_sheet("Lists")
    for j, name in enumerate(LIST_COLS, 1):
        lst.cell(row=1, column=j, value=name)
        for i, v in enumerate(lists.get(name, []), 2):
            lst.cell(row=i, column=j, value=v)
    style_table(lst, [16] * len(LIST_COLS))
    list_rng = {name: f"=Lists!${get_column_letter(j)}$2:${get_column_letter(j)}${max(2, len(lists.get(name, [])) + 1 + 40)}"
                for j, name in enumerate(LIST_COLS, 1)}
    for key in sheet_keys:
        spec = SHEETS[key]
        sh = wb.create_sheet(key)
        cols = spec["cols"]
        for j, c in enumerate(cols, 1):
            cell = sh.cell(row=1, column=j, value=c["label"])
            cell.font = Font(bold=True, color="1C1406" if c["req"] else "FFFFFF")
            cell.fill = REQ_FILL if c["req"] else HDR_FILL
            kind = c["kind"]
            fmt = {"date": "Date", "month": "Month (YYYY-MM)", "int": "Whole number", "num": "Number", "rate": "0-1 or %"}.get(kind, "Text")
            if kind.startswith(("list:", "enum:")):
                fmt = "Pick from the list"
            cell.comment = Comment(f"{fmt}. {'Required' if c['req'] else 'Optional'}. {c['help']}".strip(), "Control Tower")
            sh.column_dimensions[get_column_letter(j)].width = c["width"]
        sh.freeze_panes = "B2"
        data = rows_by_sheet.get(key, [])
        for r in data:
            sh.append([to_cell(r.get(c["key"])) if c["kind"] == "date" else r.get(c["key"]) for c in cols])
        if spec.get("id_prefix"):
            used = {str(r.get("id")) for r in data}
            n, i = len(data), 1
            while n < len(data) + id_rows:
                ident = f"{spec['id_prefix']}-{i:04d}"
                i += 1
                if ident in used:
                    continue
                sh.cell(row=n + 2, column=1, value=ident).font = Font(color="6C7D7A")
                n += 1
        last = max(sh.max_row, 2) + 300
        for j, c in enumerate(cols, 1):
            L = get_column_letter(j)
            rng = f"{L}2:{L}{last}"
            if c["kind"].startswith("list:"):
                dv = DataValidation(type="list", formula1=list_rng[c["kind"][5:]], allow_blank=True, showErrorMessage=False)
                dv.add(rng)
                sh.add_data_validation(dv)
            elif c["kind"].startswith("enum:"):
                dv = DataValidation(type="list", formula1='"' + ",".join(c["kind"][5:].split("|")) + '"', allow_blank=True,
                                    showErrorMessage=True, error="Pick a value from the list", errorTitle=c["label"])
                dv.add(rng)
                sh.add_data_validation(dv)
            elif c["kind"] == "date":
                for i in range(2, last):
                    sh.cell(row=i, column=j).number_format = "yyyy-mm-dd"
            elif c["kind"] in ("text", "month"):
                for i in range(2, min(last, 2 + len(data) + id_rows)):
                    sh.cell(row=i, column=j).number_format = "@"
            if c["kind"] == "text" and c["width"] >= 30:
                for i in range(2, 2 + len(data)):
                    sh.cell(row=i, column=j).alignment = Alignment(wrap_text=True, vertical="top")
    wb.move_sheet("Lists", offset=len(wb.sheetnames))
    if "Lists" not in [k for k in sheet_keys] and "Models" not in sheet_keys:
        wb["Lists"].sheet_state = "hidden"
    wb.save(path)


def to_cell(v):
    if isinstance(v, str) and re.match(r"^\d{4}-\d{2}-\d{2}$", v):
        return dt.date.fromisoformat(v)
    return v


def make_templates(lists=None):
    out = os.path.join(ROOT, "templates")
    os.makedirs(out, exist_ok=True)
    if lists is None:
        log = Log()
        _, lists, _ = read_inputs(INPUTS, log)
    write_input_workbook(os.path.join(out, "Master.xlsx"), ["Models", "Results", "Settings"], {}, lists, id_rows=0,
                         readme_title="Master file: models in production, optional results and settings (kept by you)")
    write_input_workbook(os.path.join(out, "Program_Requests.xlsx"), ["Requests"], {}, lists,
                         readme_title="Program requests: issues and requests from program leads and members")
    write_input_workbook(os.path.join(out, "Pod_Concerns.xlsx"), ["Concerns"], {}, lists,
                         readme_title="Pod concerns: concerns raised by pod specs (Humana, UHC, Aetna, Devoted)")
    write_input_workbook(os.path.join(out, "Developer_Log.xlsx"), ["Developer log"], {}, lists,
                         readme_title="Developer log: changes and drift seen in training or scoring data")
    print(f"Blank templates written to {out} (dropdowns use the current Lists).")


# ---------------------------------------------------------------------------
# biweekly reports
# ---------------------------------------------------------------------------
def fortnight(settings, today, end_override=None):
    if end_override:
        end = p_date(end_override)
        return end - dt.timedelta(days=13), end
    try:
        anchor = p_date(settings.get("report_anchor_date") or "2026-01-05")
    except ValueError:
        anchor = dt.date(2026, 1, 5)
    n = (today - anchor).days // 14
    start = anchor + dt.timedelta(days=14 * (n - 1)) if n >= 1 else today - dt.timedelta(days=14)
    return start, start + dt.timedelta(days=13)


def d_(s):
    return dt.date.fromisoformat(s) if s else None


def model_status_rows(models, settings, end):
    rows = []
    for m in models:
        if m["status"] not in ("Production",):
            continue
        cad = cadence_for(m, settings)
        due = m["last_retrained"] + dt.timedelta(days=cad)
        state = "Overdue" if due < end else ("Due within 30 days" if (due - end).days <= 30 else "On schedule")
        rows.append(dict(pod=m["pod"], segment=m["segment"], program=m["program"], version=str(m["version"]),
                         last=m["last_retrained"], due=due, state=state, owner=m.get("owner") or "", cadence=cad))
    order = {"Overdue": 0, "Due within 30 days": 1, "On schedule": 2}
    return sorted(rows, key=lambda r: (order[r["state"]], r["due"]))


def report_data(ctx, audience, flt, start, end):
    items = [i for i in ctx["items"] if flt(i)]
    devlog = [d for d in ctx["devlog"] if flt(d) and start <= d_(d["date"]) <= end]
    models = model_status_rows([m for m in ctx["models"] if flt(m)], ctx["settings"], end)
    raised = [i for i in items if start <= d_(i["date"]) <= end]
    closed = [i for i in items if i["closed_on"] and start <= d_(i["closed_on"]) <= end]
    def open_at(day):
        return [i for i in items if d_(i["date"]) <= day and not (i["closed_on"] and d_(i["closed_on"]) <= day) and (i["open"] or i["closed_on"])]
    open_end = [i for i in items if d_(i["date"]) <= end and (i["open"] or (i["closed_on"] and d_(i["closed_on"]) > end))]
    for i in open_end:
        i["_age_end"] = (end - d_(i["date"])).days
        i["_overdue_end"] = d_(i["due"]) < end and norm(i["status"]) != "onhold" 
    overdue = [i for i in open_end if i["_overdue_end"]]
    ttc = [(d_(i["closed_on"]) - d_(i["date"])).days for i in closed]
    snap = load_snapshot_on_or_before(start - dt.timedelta(days=1))
    moved = []
    if snap:
        for i in items:
            prev = snap["items"].get(i["key"])
            if prev and prev["status"] != i["status"] and i not in closed:
                moved.append((i, prev["status"]))
    # impact: latest complete month with data on or before the period end
    res = [r for r in ctx["results"] if flt(r) and r["month"] <= f"{end.year}-{end.month:02d}"]
    impact = None
    if res:
        months = sorted({r["month"] for r in res})
        last = months[-1]
        prev = months[-2] if len(months) > 1 else None
        def agg(mo):
            rr = [r for r in res if r["month"] == mo]
            s = lambda k: sum((r.get(k) or 0) for r in rr)
            sel, fnd = s("claims_selected"), s("findings")
            return dict(month=mo, scored=s("claims_scored"), selected=sel, findings=fnd, confirmed=s("confirmed_findings"),
                        validated=s("validated_amount"), recovered=s("recovered_amount"), hit=(fnd / sel) if sel else None)
        impact = dict(cur=agg(last), prev=agg(prev) if prev else None)
    hl = []
    n_o = len(open_end)
    hl.append(f"{len(raised)} raised and {len(closed)} closed in the period; {n_o} open at the end, {len(overdue)} past due.")
    if overdue:
        o = max(overdue, key=lambda i: i["_age_end"])
        hl.append(f"Oldest overdue: {o['id']} '{o['title']}' ({o['_age_end']} days open, owner {o['owner'] or 'not assigned'}).")
    unassigned = [i for i in open_end if not i["owner"]]
    if unassigned:
        hl.append(f"{len(unassigned)} open item(s) have no owner: {', '.join(i['id'] for i in unassigned[:6])}.")
    od = [m for m in models if m["state"] == "Overdue"]
    if od:
        hl.append("Retraining overdue: " + "; ".join(f"{m['pod']} {m['segment']} {m['program']} (due {fmt_date(m['due'])})" for m in od[:5]) + ".")
    soon = [m for m in models if m["state"] == "Due within 30 days"]
    if soon:
        hl.append("Retraining due within 30 days: " + "; ".join(f"{m['pod']} {m['segment']} {m['program']} ({fmt_date(m['due'])})" for m in soon[:5]) + ".")
    if devlog:
        drift = sum(1 for d in devlog if "drift" in norm(d["change_type"]))
        hl.append(f"{len(devlog)} developer update(s) logged" + (f", {drift} on drift" if drift else "") + ".")
    hi = [d for d in devlog if d["severity"] == "High"]
    for d in hi[:3]:
        num = f" {metric_txt(d)}." if d["before"] is not None or d["after"] is not None else ""
        hl.append(f"Developer note (high): {d['pod']} {d['segment']} {d['program']}, {d['change_type'].lower()}.{num} {d['details']}".strip())
    if impact and impact["cur"]["validated"]:
        c, p = impact["cur"], impact["prev"]
        chg = f" ({(c['validated'] / p['validated'] - 1) * 100:+.1f}% vs {month_name(p['month'])})" if p and p["validated"] else ""
        hl.append(f"{month_name(c['month'])}: {c['findings']:,} findings, ${c['validated']:,.0f} validated{chg}.")
    by_type = defaultdict(int)
    for i in open_end:
        by_type[i["type"] or "Other"] += 1
    return dict(audience=audience, start=start, end=end, items=items, raised=raised, closed=closed, open_end=sorted(open_end, key=lambda i: (not i["_overdue_end"], -i["_age_end"])),
                overdue=overdue, ttc=ttc, moved=moved, devlog=sorted(devlog, key=lambda d: d["date"], reverse=True), models=models,
                impact=impact, highlights=hl, by_type=dict(by_type), synthetic=str(ctx["settings"].get("data_classification", "")).upper() == "SYNTHETIC",
                open_start=len(open_at(start - dt.timedelta(days=1))))


def month_name(m):
    return dt.date(int(m[:4]), int(m[5:7]), 1).strftime("%b %Y") if m else ""


def fmt_val(d, k):
    v = d.get(k)
    if v is None:
        return "-"
    if d.get("is_rate"):
        return f"{v * 100:.1f}%"
    return f"{v:,.3f}" if abs(v) < 10 and not float(v).is_integer() else f"{v:,.0f}"


def metric_txt(d):
    if not d.get("metric"):
        return "-"
    if d.get("before") is None and d.get("after") is None:
        return d["metric"]
    if d.get("before") is None:
        return f"{d['metric']}: {fmt_val(d, 'after')}"
    return f"{d['metric']}: {fmt_val(d, 'before')} to {fmt_val(d, 'after')}"


def audiences(ctx):
    yield "Overall", "Overall", lambda r: True
    pods = OrderedDict((p, 1) for p in ctx["lists"].get("Pod", []))
    for coll in (ctx["models"], ctx["items"]):
        for r in coll:
            if r.get("pod"):
                pods.setdefault(r["pod"], 1)
    for p in pods:
        f = (lambda p: lambda r: norm(r.get("pod")) == norm(p))(p)
        if any(f(r) for r in ctx["models"]) or any(f(r) for r in ctx["items"]):
            yield f"Pod - {p}", p, f
    progs = OrderedDict((p, 1) for p in ctx["lists"].get("Program", []))
    for coll in (ctx["models"], ctx["items"]):
        for r in coll:
            if r.get("program"):
                progs.setdefault(r["program"], 1)
    for p in progs:
        f = (lambda p: lambda r: norm(r.get("program")) == norm(p))(p)
        if any(f(r) for r in ctx["models"]) or any(f(r) for r in ctx["items"]):
            yield f"Program - {p}", p, f


def safe_name(s):
    return re.sub(r'[<>:"/\\|?*]+', "-", s).strip()


def run_reports(ctx, end_override=None, open_folder=False):
    start, end = fortnight(ctx["settings"], ctx["today"], end_override)
    folder = os.path.join(OUT_DIR, "reports", f"{start.isoformat()}_to_{end.isoformat()}")
    os.makedirs(folder, exist_ok=True)
    try:
        import fpdf  # noqa: F401
        have_pdf = True
    except ImportError:
        have_pdf = False
        print("The fpdf2 package is missing, so only Excel reports were written. Run setup.bat to add PDF reports.")
    emails, n = [], 0
    for fname, label, flt in audiences(ctx):
        rep = report_data(ctx, label, flt, start, end)
        base = os.path.join(folder, safe_name(fname))
        write_report_xlsx(rep, base + ".xlsx")
        if have_pdf:
            write_report_pdf(rep, base + ".pdf")
        emails.append(email_text(rep))
        n += 1
    with open(os.path.join(folder, "email_summaries.txt"), "w", encoding="utf-8") as fh:
        fh.write(("\n\n" + "=" * 72 + "\n\n").join(emails))
    print(f"Wrote {n} report(s) for {fmt_date(start)} to {fmt_date(end)} in {folder}")
    if open_folder and hasattr(os, "startfile"):
        os.startfile(folder)  # noqa: S606 (Windows only)
    return folder


def email_text(rep):
    who = "all pods and programs" if rep["audience"] == "Overall" else rep["audience"]
    lines = [f"Subject: ML model update for {who}, {fmt_date(rep['start'])} to {fmt_date(rep['end'])}", "",
             "Hi all,", "", f"Here is the biweekly update for {who}.", ""]
    lines += [f"- {h}" for h in rep["highlights"]]
    if rep["closed"]:
        lines += ["", "Closed this period:"] + [f"- {i['id']} {i['title']}: {i['resolution'] or 'closed'}" for i in rep["closed"][:8]]
    if rep["overdue"]:
        lines += ["", "Needs attention:"] + [f"- {i['id']} {i['title']} (owner {i['owner'] or 'not assigned'}, due {fmt_date(i['due'])})" for i in rep["overdue"][:8]]
    lines += ["", "The full report is attached (PDF), with the item list in Excel.", ""]
    if rep["synthetic"]:
        lines.insert(0, "[SYNTHETIC SAMPLE DATA - not actual client results]")
    return "\n".join(lines)


def item_rows(items, end, new_ids=()):
    out = []
    for i in items:
        age = i.get("_age_end", i["age_days"])
        due = d_(i["due"])
        state = f"Overdue {(end - due).days}d" if i.get("_overdue_end") else ("Due " + fmt_date(due) if i["open"] or i.get("_age_end") is not None else "")
        out.append([i["id"] + (" (new)" if i["key"] in new_ids else ""), i["kind"], i["title"],
                    " / ".join(x for x in (i["pod"], i["segment"], i["program"]) if x), i["priority"], i["status"], i["owner"] or "Not assigned", age, state])
    return out


def write_report_xlsx(rep, path):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Summary"
    ws["A1"] = f"{rep['audience']}: ML model update"
    ws["A1"].font = Font(bold=True, size=15)
    ws["A2"] = f"{fmt_date(rep['start'])} to {fmt_date(rep['end'])}. Generated {dt.datetime.now():%d %b %Y %H:%M}."
    r0 = 3
    if rep["synthetic"]:
        ws["A3"] = "Synthetic sample data. Not actual client results."
        ws["A3"].font = Font(bold=True, color="B42318")
        r0 = 4
    kp = kpis(rep)
    for j, (lab, val) in enumerate(kp):
        ws.cell(row=r0 + 1, column=j + 1, value=lab).font = Font(color="5E6662")
        ws.cell(row=r0 + 2, column=j + 1, value=val).font = Font(bold=True, size=14)
    ws.cell(row=r0 + 4, column=1, value="Highlights").font = Font(bold=True)
    for k, h in enumerate(rep["highlights"]):
        ws.cell(row=r0 + 5 + k, column=1, value="• " + h)
    e0 = r0 + 6 + len(rep["highlights"])
    ws.cell(row=e0, column=1, value="Email text").font = Font(bold=True)
    for k, line in enumerate(email_text(rep).split("\n")):
        ws.cell(row=e0 + 1 + k, column=1, value=line)
    for j in range(1, 8):
        ws.column_dimensions[get_column_letter(j)].width = 18
    heads = ["ID", "Type", "Title", "Pod / segment / program", "Priority", "Status", "Owner", "Days open", "Due"]
    new_ids = {i["key"] for i in rep["raised"]}
    for title, items in (("Open items", rep["open_end"]), ("Raised this period", rep["raised"])):
        s = wb.create_sheet(title)
        s.append(heads)
        for r in item_rows(items, rep["end"], new_ids if title == "Open items" else ()):
            s.append(r)
        style_table(s, [12, 10, 48, 30, 10, 12, 18, 10, 16])
    s = wb.create_sheet("Closed this period")
    s.append(["ID", "Type", "Title", "Pod / segment / program", "Raised", "Closed", "Days to close", "Owner", "Resolution"])
    for i in rep["closed"]:
        s.append([i["id"], i["kind"], i["title"], " / ".join(x for x in (i["pod"], i["segment"], i["program"]) if x), d_(i["date"]), d_(i["closed_on"]),
                  (d_(i["closed_on"]) - d_(i["date"])).days, i["owner"], i["resolution"]])
    style_table(s, [12, 10, 44, 28, 12, 12, 12, 18, 60])
    s = wb.create_sheet("Models")
    s.append(["Pod", "Segment", "Program", "Version", "Last retrained", "Retrain due", "Status", "Cadence (days)", "Owner"])
    for m in rep["models"]:
        s.append([m["pod"], m["segment"], m["program"], m["version"], m["last"], m["due"], m["state"], m["cadence"], m["owner"]])
    style_table(s, [12, 16, 14, 9, 14, 14, 20, 14, 18])
    s = wb.create_sheet("Developer updates")
    s.append(["Date", "ID", "Pod", "Segment", "Program", "Version", "Change type", "Feature / area", "Metric", "Before", "After", "Severity", "Details", "Action taken"])
    for d in rep["devlog"]:
        s.append([d_(d["date"]), d["id"], d["pod"], d["segment"], d["program"], d["version"], d["change_type"], d["area"], d["metric"],
                  d["before"], d["after"], d["severity"], d["details"], d["action"]])
    style_table(s, [12, 10, 10, 12, 14, 8, 16, 22, 18, 9, 9, 9, 60, 40])
    if rep["impact"]:
        s = wb.create_sheet("Impact")
        s.append(["Month", "Claims scored", "Claims selected", "Findings", "Confirmed", "Hit rate", "Validated $", "Recovered $"])
        for k in ("prev", "cur"):
            a = rep["impact"].get(k)
            if a:
                s.append([month_name(a["month"]), a["scored"], a["selected"], a["findings"], a["confirmed"], a["hit"], a["validated"], a["recovered"]])
        style_table(s, [12, 14, 14, 10, 10, 10, 16, 16])
        for row in s.iter_rows(min_row=2):
            row[5].number_format = "0.0%"
            row[6].number_format = row[7].number_format = "$#,##0"
    for sh in wb.worksheets[1:]:
        for row in sh.iter_rows(min_row=2):
            for c in row:
                if isinstance(c.value, dt.date):
                    c.number_format = "dd mmm yyyy"
    safe_save(wb, path)


def kpis(rep):
    med = f"{statistics.median(rep['ttc']):.0f} days" if rep["ttc"] else "-"
    return [("Open at start", rep["open_start"]), ("Raised", len(rep["raised"])), ("Closed", len(rep["closed"])),
            ("Open at end", len(rep["open_end"])), ("Past due", len(rep["overdue"])), ("Median days to close", med),
            ("Retraining overdue", sum(m["state"] == "Overdue" for m in rep["models"]))]


# ---------------------------------------------------------------------------
# PDF
# ---------------------------------------------------------------------------
INK, DIM, LINE, ACC, BAND, PAPER = (29, 37, 35), (94, 102, 98), (217, 223, 220), (232, 163, 61), (28, 38, 40), (246, 241, 225)
RED, AMB = (184, 48, 63), (194, 90, 23)
FALLBACK = {"→": "->", "←": "<-", "✓": "Yes", "✗": "No", "₹": "Rs ", "≥": ">=", "≤": "<=", "…": "...", "’": "'", "‘": "'", "“": '"', "”": '"'}


def pdf_text(s, unicode_ok):
    s = "" if s is None else str(s)
    for a, b in FALLBACK.items():
        s = s.replace(a, b)
    if unicode_ok:
        return "".join(ch if (ord(ch) < 0x250 or ch in "•–—€") else (unicodedata.normalize("NFKD", ch).encode("ascii", "ignore").decode() or "?") for ch in s)
    return unicodedata.normalize("NFKD", s).encode("latin-1", "ignore").decode("latin-1")


def write_report_pdf(rep, path):
    from fpdf import FPDF
    from fpdf.fonts import FontFace

    class PDF(FPDF):
        def footer(self):
            self.set_y(-12)
            self.set_font(BODY, size=7.5)
            self.set_text_color(*DIM)
            note = "Synthetic sample data - not actual client results. " if rep["synthetic"] else ""
            self.cell(0, 5, T(f"{note}ML Model Control Tower | {rep['audience']} | {fmt_date(rep['start'])} to {fmt_date(rep['end'])} | page {self.page_no()}/{{nb}}"), align="C")

    pdf = PDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(True, margin=16)
    pdf.set_margins(14, 14, 14)
    ok = all(os.path.exists(os.path.join(FONTS, f)) for f in ("Barlow-Regular.ttf", "Barlow-SemiBold.ttf", "BarlowCondensed-SemiBold.ttf"))
    if ok:
        pdf.add_font("Barlow", "", os.path.join(FONTS, "Barlow-Regular.ttf"))
        pdf.add_font("Barlow", "B", os.path.join(FONTS, "Barlow-SemiBold.ttf"))
        pdf.add_font("BarlowC", "", os.path.join(FONTS, "BarlowCondensed-SemiBold.ttf"))
        BODY, HEAD = "Barlow", "BarlowC"
    else:
        BODY, HEAD = "helvetica", "helvetica"
    T = lambda s: pdf_text(s, ok)  # noqa: E731
    pdf.add_page()
    W = pdf.w - 28
    # title band
    pdf.set_fill_color(*BAND)
    pdf.rect(0, 0, pdf.w, 30, style="F")
    pdf.set_fill_color(*ACC)
    pdf.rect(0, 30, pdf.w, 1.2, style="F")
    pdf.set_xy(14, 8)
    pdf.set_text_color(255, 255, 255)
    pdf.set_font(HEAD, size=21)
    title = "ML model update: all pods and programs" if rep["audience"] == "Overall" else f"ML model update: {rep['audience']}"
    pdf.cell(W, 9, T(title))
    pdf.set_xy(14, 18.5)
    pdf.set_font(BODY, size=9.5)
    pdf.set_text_color(214, 222, 218)
    pdf.cell(W, 6, T(f"Biweekly report, {fmt_date(rep['start'])} to {fmt_date(rep['end'])}. Generated {dt.datetime.now():%d %b %Y}."))
    pdf.set_y(36)
    if rep["synthetic"]:
        pdf.set_font(BODY, "B", 8.5)
        pdf.set_text_color(*RED)
        pdf.cell(W, 5, T("Synthetic sample data for illustration. Not actual client results."), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(1)
    # KPI tiles
    kp = kpis(rep)
    tw, gap = (W - 6 * 2) / 7, 2
    y = pdf.get_y()
    for j, (lab, val) in enumerate(kp):
        x = 14 + j * (tw + gap)
        pdf.set_fill_color(*PAPER)
        pdf.rect(x, y, tw, 17, style="F")
        warn = (lab in ("Past due", "Retraining overdue") and val not in (0, "-"))
        pdf.set_fill_color(*(RED if warn else ACC))
        pdf.rect(x, y, 1.3, 17, style="F")
        pdf.set_xy(x + 3, y + 1.8)
        pdf.set_font(HEAD, size=15)
        pdf.set_text_color(*(RED if warn else INK))
        pdf.cell(tw - 4, 7, T(val))
        pdf.set_xy(x + 3, y + 9.5)
        pdf.set_font(BODY, size=7)
        pdf.set_text_color(*DIM)
        pdf.multi_cell(tw - 4, 3.2, T(lab))
    pdf.set_y(y + 21)

    def heading(t, sub=""):
        if pdf.get_y() > pdf.h - 40:
            pdf.add_page()
        pdf.ln(2)
        pdf.set_font(HEAD, size=13)
        pdf.set_text_color(*INK)
        pdf.cell(pdf.get_string_width(T(t)) + 3, 7, T(t))
        if sub:
            pdf.set_font(BODY, size=8.5)
            pdf.set_text_color(*DIM)
            pdf.cell(0, 7, T(sub))
        pdf.ln(7.5)
        pdf.set_draw_color(*LINE)

    def table(heads, rows, widths, align=None, emph=None):
        if not rows:
            pdf.set_font(BODY, size=9)
            pdf.set_text_color(*DIM)
            pdf.cell(0, 6, T("None in this period."), new_x="LMARGIN", new_y="NEXT")
            return
        pdf.set_font(BODY, size=8)
        pdf.set_text_color(*INK)
        pdf.set_draw_color(*LINE)
        pdf.set_fill_color(248, 246, 239)
        hs = FontFace(family=BODY, emphasis="BOLD", color=(255, 255, 255), fill_color=BAND, size_pt=8)
        with pdf.table(col_widths=widths, width=W, headings_style=hs, line_height=4.3, padding=(1.2, 1.5, 1.2, 1.5),
                       borders_layout="HORIZONTAL_LINES", cell_fill_color=(248, 246, 239), cell_fill_mode="ROWS",
                       text_align=align or "LEFT", first_row_as_headings=True) as tb:
            hr = tb.row()
            for h in heads:
                hr.cell(T(h))
            for r in rows:
                rr = tb.row()
                for j, v in enumerate(r):
                    style = None
                    if emph and emph(j, v):
                        style = FontFace(family=BODY, emphasis="BOLD", color=RED)
                    rr.cell(T(v if not isinstance(v, (int, float)) or isinstance(v, bool) else (f"{v:,}" if isinstance(v, int) else f"{v:,.2f}")), style=style)

    heading("Highlights")
    pdf.set_font(BODY, size=9.5)
    pdf.set_text_color(*INK)
    for h in rep["highlights"]:
        pdf.set_x(16)
        pdf.multi_cell(W - 2, 4.8, T("• " + h), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(0.6)
    new_ids = {i["key"] for i in rep["raised"]}
    heading("Open items", "past due first, then oldest; (new) = raised this period")
    rows = [r[:3] + [r[3], r[4], r[6], str(r[7]), r[8]] for r in item_rows(rep["open_end"], rep["end"], new_ids)]
    table(["ID", "Type", "Title", "Pod / program", "Priority", "Owner", "Days", "Due"], rows, (16, 15, 55, 31, 13, 22, 9, 21),
          emph=lambda j, v: j == 7 and str(v).startswith("Overdue"))
    heading("Closed this period")
    table(["ID", "Title", "Closed", "Days", "Resolution"],
          [[i["id"], i["title"], fmt_date(i["closed_on"]), str((d_(i["closed_on"]) - d_(i["date"])).days), i["resolution"] or "-"] for i in rep["closed"]],
          (15, 50, 20, 9, 88))
    if rep["moved"]:
        heading("Status changes", "since the last snapshot before this period")
        table(["ID", "Title", "Was", "Now", "Owner"], [[i["id"], i["title"], prev, i["status"], i["owner"]] for i, prev in rep["moved"]], (15, 82, 22, 22, 41))
    heading("Models", "production models; retraining status at the end of the period")
    table(["Pod", "Segment", "Program", "Version", "Last retrained", "Retrain due", "Status"],
          [[m["pod"], m["segment"], m["program"], "v" + m["version"], fmt_date(m["last"]), fmt_date(m["due"]), m["state"]] for m in rep["models"]],
          (20, 28, 26, 14, 28, 28, 38), emph=lambda j, v: j == 6 and v == "Overdue")
    heading("Developer updates", "changes and drift logged this period")
    table(["Date", "Model", "Change", "Metric: before to after", "Sev.", "Details"],
          [[fmt_date(d["date"]), f"{d['pod']} {d['segment']} {d['program']}", d["change_type"],
            metric_txt(d), d["severity"] or "-",
            d["details"] + (f" Action: {d['action']}" if d["action"] else "")] for d in rep["devlog"]],
          (19, 30, 22, 30, 10, 71), emph=lambda j, v: j == 4 and v == "High")
    if rep["impact"]:
        a, p = rep["impact"]["cur"], rep["impact"]["prev"]
        heading("Business impact", "latest complete month in the results sheet")
        fm = lambda x, k: (f"{x[k] * 100:.1f}%" if k == "hit" and x[k] is not None else (f"${x[k]:,.0f}" if k in ("validated", "recovered") else f"{x[k]:,}")) if x else "-"  # noqa: E731
        rows = [[lab, fm(p, k) if p else "-", fm(a, k)] for lab, k in (("Claims scored", "scored"), ("Claims selected", "selected"), ("Findings", "findings"),
                                                                       ("Confirmed findings", "confirmed"), ("Hit rate", "hit"), ("Validated $", "validated"), ("Recovered $", "recovered"))]
        table(["", month_name(p["month"]) if p else "Previous", month_name(a["month"])], rows, (60, 60, 62))
    pdf.alias_nb_pages()
    try:
        pdf.output(path)
    except PermissionError:
        alt = path.replace(".pdf", f"_{dt.datetime.now():%H%M%S}.pdf")
        pdf.output(alt)
        print(f"  {os.path.basename(path)} is open; saved as {os.path.basename(alt)} instead.")



# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def signature():
    out = []
    for p in discover_inputs(INPUTS):
        try:
            st = os.stat(p)
            out.append((p, st.st_mtime, st.st_size))
        except OSError:
            pass
    return tuple(out)


def open_dashboard():
    if not os.path.exists(HTML):
        print(f"Dashboard file not found: {HTML}")
        return
    if hasattr(os, "startfile"):
        os.startfile(HTML)  # noqa: S606
    else:
        import webbrowser
        webbrowser.open("file://" + HTML)


def main():
    ap = argparse.ArgumentParser(description="Refresh the ML Model Control Tower and write biweekly reports.")
    ap.add_argument("--open", action="store_true", help="open the dashboard after refreshing")
    ap.add_argument("--watch", action="store_true", help="keep running and refresh when an input file is saved")
    ap.add_argument("--interval", type=int, default=20, help="seconds between checks in watch mode (default 20)")
    ap.add_argument("--report", action="store_true", help="also write the biweekly PDF and Excel reports")
    ap.add_argument("--period-end", help="last day of the report period, e.g. 2026-11-15 (default: last complete fortnight)")
    ap.add_argument("--open-report", action="store_true", help="open the report folder when done (Windows)")
    ap.add_argument("--make-templates", action="store_true", help="write blank input files to templates/")
    ap.add_argument("--today", help=argparse.SUPPRESS)
    a = ap.parse_args()
    today = p_date(a.today) if a.today else None
    if a.make_templates:
        make_templates()
        return
    ctx = build(today)
    if a.report:
        run_reports(ctx, a.period_end, a.open_report)
        build(today, quiet=True)  # refresh the report list shown in the dashboard
    if a.open:
        open_dashboard()
    if a.watch:
        print(f"Watching {INPUTS} every {a.interval}s. Save an Excel file to refresh; the open dashboard updates itself. Ctrl+C to stop.")
        sig = signature()
        try:
            while True:
                time.sleep(a.interval)
                s = signature()
                if s != sig:
                    time.sleep(1.5)  # let Excel finish writing
                    sig = signature()
                    print(f"[{dt.datetime.now():%H:%M:%S}] Change detected.")
                    try:
                        build(today)
                    except Exception as e:  # noqa: BLE001
                        print(f"  Refresh failed: {e}. Will retry on the next change.")
        except KeyboardInterrupt:
            print("Stopped watching.")


if __name__ == "__main__":
    main()
