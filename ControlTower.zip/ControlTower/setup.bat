@echo off
title Control Tower - setup
cd /d "%~dp0"
call :findpy || goto nopy
echo Installing the two Python packages the script needs (openpyxl, fpdf2)...
%PY% -m pip install --user --upgrade openpyxl fpdf2
if errorlevel 1 (echo. & echo Install failed. If you are behind a proxy, ask IT to allow pip, or install the packages manually. & pause & exit /b 1)
echo.
echo Setup finished. Double-click refresh.bat to build the dashboard.
pause
exit /b 0

:nopy
echo Python 3 was not found. Install it from https://www.python.org/downloads/
echo (tick "Add python.exe to PATH"), then double-click setup.bat.
pause
exit /b 1

:findpy
where py >nul 2>nul && (set "PY=py -3" & exit /b 0)
where python >nul 2>nul && (set "PY=python" & exit /b 0)
exit /b 1
